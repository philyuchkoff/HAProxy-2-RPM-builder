Этот репозиторий содержит некоторые артефакты для сборки HAProxy самой свежей версии из ветки 1.9. 
В yum лежит старинная версия, и, если кому-то, как и мне, понадобится пакет со свежим HAProxy (например, для балансировки gRPC https://grpc.io/), то здесь есть всё необходимое для этого.
Чтобы было совсем красиво, сначала установите себе OpenSSL 1.1.1c (самая свежая на данный момент), проверить установленную у вас версию можно командой

    openssl version
    
должно ответить так:

    OpenSSL 1.1.1c  28 May 2019

# RPM Specs for HAproxy on CentOS with default syslog

Для сборки пакета выполните следующие действия под обычным пользователем.

## Установка необходимого для сборки  RPM

    sudo yum groupinstall 'Development Tools'

## Checkout this repository

    cd /opt
    git clone https://github.com/philyuchkoff/haproxy-1.9-RPM-builder.git
    cd ./rpm-haproxy
    git checkout 1.9

## Build using makefile
    make
    
Собранный RPM будет лежать в /opt/rpm-haproxy/rpmbuild/RPMS/x86_64/

## Спасибо

Based on the Red Hat 6.4 RPM spec for haproxy 1.4 combined with work done by 
- David Bezemer (https://github.com/DBezemer/rpm-haproxy/)
- [@nmilford](https://www.github.com/nmilford)
- [@resmo](https://www.github.com/resmo) 
- [@kevholmes](https://www.github.com/kevholmes)
- Update to 1.8 contributed by [@khdevel](https://github.com/khdevel)
- Version detect snippet by [@hiddenstream](https://github.com/hiddenstream)
